var players = {};
var youtubeAPIReady = false;

function onYouTubeIframeAPIReady() {
    youtubeAPIReady = true;
    console.log("✅ [YouTube API] IFrame API 로드 완료");

    document.querySelectorAll(".video-container").forEach(container => {
        let videoId = container.getAttribute("data-video-id");
        createPlayer(videoId);
    });
}

function createPlayer(videoId) {
    let container = document.querySelector(`[data-video-id='${videoId}']`);
    if (!container) {
        console.log(`❌ [YouTube] video-${videoId} 컨테이너를 찾을 수 없음`);
        return;
    }

    container.innerHTML = "";

    let iframe = document.createElement("iframe");
    iframe.setAttribute("id", `player-${videoId}`);
    iframe.setAttribute("width", "560");
    iframe.setAttribute("height", "315");
    iframe.setAttribute("src", `https://www.youtube.com/embed/${videoId}?enablejsapi=1`);
    iframe.setAttribute("frameborder", "0");
    iframe.setAttribute("allowfullscreen", "");

    container.appendChild(iframe);

    players[videoId] = new YT.Player(`player-${videoId}`, {
        events: {
            'onReady': function(event) {
                console.log(`✅ [YouTube API] Player ready for video: ${videoId}`);
            }
        }
    });

    console.log(`🎬 [YouTube] 새로운 플레이어 생성: ${videoId}`);
}

document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".video-container").forEach(container => {
        let videoId = container.getAttribute("data-video-id");
        createPlayer(videoId);
    });

    document.querySelectorAll(".timestamp").forEach(ts => {
        ts.addEventListener("click", function(event) {
            let videoId = event.target.dataset.video;
            let seconds = parseFloat(event.target.dataset.seconds);

            console.log(`🎯 [JavaScript] 클릭한 타임스탬프: videoId=${videoId}, seconds=${seconds}`);

            if (!players[videoId]) {
                console.log(`⚠️ [JavaScript] 플레이어가 존재하지 않음. 새로 생성.`);
                createPlayer(videoId);
                
                setTimeout(() => {
                    if (players[videoId]) {
                        console.log(`✅ [JavaScript] 지연 후 seekTo 실행: ${seconds}초`);
                        players[videoId].seekTo(seconds, true);
                        players[videoId].playVideo();
                    } else {
                        console.log(`❌ [JavaScript] 여전히 seekTo() 실행 불가: videoId=${videoId}`);
                    }
                }, 1000);
                return;
            }

            console.log(`🔹 [JavaScript] seekTo 실행: ${seconds}초로 이동`);
            players[videoId].seekTo(seconds, true);
            players[videoId].playVideo();
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    console.log("📌 YouTube API 및 타임스탬프 초기화");

    let players = {}; // 플레이어 저장 객체

    function initializeYouTubePlayers() {
        console.log("✅ YouTube 플레이어 초기화 실행");
        document.querySelectorAll(".video-wrapper").forEach(container => {
            let videoId = container.dataset.videoId;
            if (videoId && !players[videoId]) { // 중복 생성 방지
                console.log("🎥 Initializing player for:", videoId);
                players[videoId] = new YT.Player(container, {
                    height: '350',
                    width: '100%',
                    videoId: videoId,
                    playerVars: { 'autoplay': 0, 'controls': 1 },
                    events: {
                        'onReady': function(event) {
                            console.log(`✅ [YouTube API] Player ready for video: ${videoId}`);
                        }
                    }
                });
            }
        });
    }

    function attachTimestampListeners() {
        console.log("✅ 타임스탬프 클릭 이벤트 리스너 적용");
        document.querySelectorAll(".timestamp").forEach(timestamp => {
            timestamp.addEventListener("click", function (event) {
                event.preventDefault();
                let videoId = this.dataset.video;
                let seconds = parseInt(this.dataset.seconds);
                console.log(`🎯 [JavaScript] 클릭한 타임스탬프: videoId=${videoId}, seconds=${seconds}`);

                // 플레이어가 존재하는지 확인 후 seekTo 실행
                if (players[videoId] && typeof players[videoId].seekTo === "function") {
                    console.log(`🔹 [JavaScript] seekTo 실행: ${seconds}초로 이동`);
                    players[videoId].seekTo(seconds, true);
                } else {
                    console.error(`❌ [YouTube] 플레이어가 아직 초기화되지 않음 ${videoId}`);
                    setTimeout(() => {
                        if (players[videoId] && typeof players[videoId].seekTo === "function") {
                            console.log(`✅ [JavaScript] 지연 후 seekTo 실행: ${seconds}초`);
                            players[videoId].seekTo(seconds, true);
                        }
                    }, 1000); // 1초 후 다시 시도
                }
            });
        });
    }

    if (typeof YT !== "undefined" && YT && YT.Player) {
        initializeYouTubePlayers();
        attachTimestampListeners();
    } else {
        console.warn("⚠️ YT API가 아직 로드되지 않음, 재시도");
        setTimeout(() => {
            initializeYouTubePlayers();
            attachTimestampListeners();
        }, 1000); // 1초 후 재시도
    }
});


function toggleDropdown() {
    let menu = document.getElementById("dropdown-menu");
    if (menu) {
        menu.classList.toggle("show");
    }
}

function selectSearchType(type) {
    let searchTypeInput = document.getElementById("search-type");
    let dropdownButton = document.querySelector(".dropdown-button");

    if (searchTypeInput && dropdownButton) {
        searchTypeInput.value = type;
        dropdownButton.innerText = "▼"; // 🔹 버튼 텍스트를 유지 (기본값)
    }

    // ✅ 드롭다운 메뉴 닫기
    let menu = document.getElementById("dropdown-menu");
    if (menu) {
        menu.classList.remove("show");
    }
}

/* ✅ 드롭다운 외부 클릭 시 닫기 */
window.addEventListener("click", function (event) {
    let dropdown = document.querySelector(".dropdown");
    let menu = document.getElementById("dropdown-menu");

    if (dropdown && menu && !dropdown.contains(event.target)) {
        menu.classList.remove("show");
    }
});