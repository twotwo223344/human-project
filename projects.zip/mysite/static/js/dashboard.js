// JSON 데이터 가져오기
var restaurantData = JSON.parse(document.getElementById("restaurant-data").textContent);
var cafeData = JSON.parse(document.getElementById("cafe-data").textContent);
var tourData = JSON.parse(document.getElementById("tour-data").textContent);

// 데이터 가공
var restaurantLabels = restaurantData.map(item => item.name);
var restaurantRatings = restaurantData.map(item => item.rating);

var cafeLabels = cafeData.map(item => item.name);
var cafeRatings = cafeData.map(item => item.rating);

var tourLabels = tourData.map(item => item.name);
var tourRatings = tourData.map(item => item.rating);

// 맛집 차트
new Chart(document.getElementById('restaurantChart'), {
    type: 'bar',
    data: {
        labels: restaurantLabels,
        datasets: [{
            label: '맛집 평점',
            data: restaurantRatings,
            backgroundColor: 'rgba(255, 99, 132, 0.6)'
        }]
    }
});

// 카페 차트
new Chart(document.getElementById('cafeChart'), {
    type: 'bar',
    data: {
        labels: cafeLabels,
        datasets: [{
            label: '카페 평점',
            data: cafeRatings,
            backgroundColor: 'rgba(54, 162, 235, 0.6)'
        }]
    }
});

// 관광지 차트
new Chart(document.getElementById('tourChart'), {
    type: 'bar',
    data: {
        labels: tourLabels,
        datasets: [{
            label: '관광지 평점',
            data: tourRatings,
            backgroundColor: 'rgba(255, 206, 86, 0.6)'
        }]
    }
});