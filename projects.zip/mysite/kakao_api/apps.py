from django.apps import AppConfig

class KakaoApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kakao_api'
