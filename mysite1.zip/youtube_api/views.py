from django.shortcuts import render
from .models import YouTubeVideo
import json

def video_list(request):
    """저장된 동영상을 웹페이지에 표시"""
    videos_with_captions = []

    videos = YouTubeVideo.objects.all()
    for video in videos:
        parsed_captions = json.loads(video.captions) if video.captions else []  # JSON 변환
        videos_with_captions.append({
            "video": video,
            "captions": parsed_captions
        })

    return render(request, "video_list.html", {"videos_with_captions": videos_with_captions})