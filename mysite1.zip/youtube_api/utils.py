from googleapiclient.discovery import build
from pytube import YouTube
from .models import YouTubeVideo
from youtube_transcript_api import YouTubeTranscriptApi
import json
import re  # 정규식 사용을 위해 추가

# YouTube API 설정
API_KEY = 'API_KEY'
youtube = build('youtube', 'v3', developerKey=API_KEY)

def get_video_captions(video_id):
    """YouTube Data API를 사용하여 동영상의 자막이 존재하는지 확인"""
    url = f"https://www.googleapis.com/youtube/v3/captions?part=snippet&videoId={video_id}&key={API_KEY}"
    
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if "items" in data and len(data["items"]) > 0:
            return True  # 자막이 존재함
        else:
            return False  # 자막 없음
    else:
        print(f"Error fetching captions: {response.status_code}")
        return False

def search_videos_with_captions(query, max_results=5):
    """
    YouTube API로 자막이 포함된 동영상을 검색합니다.
    """
    try:
        search_response = youtube.search().list(
            q=query,
            part='snippet',
            type='video',
            videoCaption='closedCaption',
            maxResults=max_results
        ).execute()

        videos = []
        for item in search_response['items']:
            video_data = {
                'title': item['snippet']['title'],
                'video_id': item['id']['videoId'],
                'description': item['snippet']['description'],
                'published_date': item['snippet']['publishedAt'],
            }
            videos.append(video_data)
        return videos
    except Exception as e:
        print(f"Error: {e}")
        return []

def seconds_to_minutes(seconds):
    """초를 분:초 형식으로 변환"""
    minutes = int(seconds // 60)
    remaining_seconds = int(seconds % 60)
    return f"{minutes}:{remaining_seconds:02}"  # 예: 1:05 (1분 5초)

def save_video_and_captions(video_data):
    """YouTube 영상과 자막을 저장 (JSON 형태로 변환)"""
    try:
        video_id = video_data['video_id']

        # 자막 가져오기
        try:
            # 우선 한국 자막 가져오기
            transcript = YouTubeTranscriptApi.get_transcript(video_id, languages=['ko'])
        except:
            try:
                # 한국 자막이 없으면 영어 자막 가져오기
                transcript = YouTubeTranscriptApi.get_transcript(video_id, languages=['en'])
            except:
                # 그래도 실패하면 모든 언어에서 첫 번째 자막 가져오기
                transcript = YouTubeTranscriptApi.get_transcript(video_id)

        # 자막을 JSON 리스트로 변환
        captions_list = [
            {
                "start_time": seconds_to_minutes(line["start"]),
                "end_time": seconds_to_minutes(line["start"] + line["duration"]),
                "text": line["text"]
            }
            for line in transcript
        ]

        # JSON 변환
        captions_json = json.dumps(captions_list, ensure_ascii=False)

        # 데이터베이스 저장
        video, created = YouTubeVideo.objects.update_or_create(
            video_id=video_data['video_id'],
            defaults={
                'title': video_data['title'],
                'description': video_data['description'],
                'captions': captions_json,  # JSON 형태로 저장
                'published_date': video_data['published_date'],
            }
        )
        if created:
            print(f"✅ Saved new video: {video_data['title']}")
        else:
            print(f"🔄 Updated existing video: {video_data['title']}")
    except Exception as e:
        print(f"⚠️ Error saving video and captions: {e}")

def parse_srt_captions(srt_data):
    """ SRT 형식의 자막 데이터를 리스트로 변환 """
    if not srt_data:
        return []

    srt_pattern = r"(\d+)\n(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})\n(.+)"
    matches = re.findall(srt_pattern, srt_data, re.DOTALL)

    parsed_captions = []
    for match in matches:
        start_time = match[1]  # 시작 시간
        end_time = match[2]    # 끝 시간
        text = match[3].replace("\n", " ")  # 자막 내용 (줄바꿈 제거)
        parsed_captions.append({
            "start_time": start_time,
            "end_time": end_time,
            "text": text
        })

    return parsed_captions
